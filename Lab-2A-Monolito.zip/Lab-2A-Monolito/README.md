# Instrucciones rápidas
- Requiere Java 11+, Maven 3.8+ y Tomcat 10+.
- Usa el proyecto base `monolito-jsp` (Jakarta) que ya tienes.
- Entrega: código, capturas y reflexión en un PDF/MD.
